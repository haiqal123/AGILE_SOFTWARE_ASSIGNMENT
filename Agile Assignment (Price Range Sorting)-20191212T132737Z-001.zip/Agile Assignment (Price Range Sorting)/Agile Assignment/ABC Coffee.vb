﻿Imports System.ComponentModel
Imports System.Data.SqlClient
Imports System.Text
Imports System.IO

Public Class Form1
    Public SpecifiedValue As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BindData()
    End Sub

    Private Sub BindData3()
        Dim db As New StorageItemDataContext()
        Dim rs = From o In db.Items
                 Where o.ItemCategory.Contains(SpecifiedValue)

        dgv.DataSource = rs
    End Sub

    Private Sub BindData2()
        Dim db As New StorageItemDataContext()
        Dim rs = From o In db.Items
                 Where o.ItemID.Contains(txtID.Text)

        dgv.DataSource = rs
    End Sub

    Private Sub BindData()
        Dim db As New StorageItemDataContext()
        Dim rs = From o In db.Items
                 Where o.ItemName.Contains(txtName.Text)

        dgv.DataSource = rs
    End Sub

    Private Sub txtName_TextChanged(sender As Object, e As EventArgs) Handles txtName.TextChanged
        BindData()
    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        frmAdd.ShowDialog()
        BindData()
    End Sub

    Private Sub txtID_TextChanged(sender As Object, e As EventArgs) Handles txtID.TextChanged
        BindData2()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        frmUpdate.Show()
    End Sub

    Private Sub Form1_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        BindData()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        frmDelete.Show()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = 0 Then
            dgv.Sort(dgv.Columns(2), ListSortDirection.Ascending)
        ElseIf ComboBox1.SelectedIndex = 1 Then
            dgv.Sort(dgv.Columns(2), ListSortDirection.Descending)
        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub dgv_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        If ComboBox2.SelectedIndex = 0 Then
            SpecifiedValue = "Coffee"
        ElseIf ComboBox2.SelectedIndex = 1 Then
            SpecifiedValue = "Fruit Juice"
        End If

        BindData3()
    End Sub

    Private Sub btnSort_Click(sender As Object, e As EventArgs) Handles btnSort.Click
        Dim err As New StringBuilder()
        Dim ctr As Control = Nothing

        Dim fromString As String = txtFrom.Text
        Dim toString As String = txtTo.Text

        Check_Database()
    End Sub

    Private Sub Check_Database()
        Dim str As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Chunyip\Desktop\Agile Assignment (Add Quantity) - Copy - Copy (2)\Agile Assignment\Storage.mdf;Integrated Security=True"

        Dim sql As String = "select * from Items where ItemPrice between @fromString and @toString"
        Using Conn As New SqlConnection(str)
            Using cmd As New SqlCommand(sql, Conn)
                Conn.Open()

                cmd.Parameters.AddWithValue("@fromString", txtFrom.Text)
                cmd.Parameters.AddWithValue("@toString", txtTo.Text)

                Dim adapter As New SqlDataAdapter(cmd)

                Dim table As New DataTable

                adapter.Fill(table)

                dgv.DataSource = table
            End Using

        End Using
    End Sub
End Class

