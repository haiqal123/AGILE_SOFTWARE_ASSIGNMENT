﻿Imports System.Text
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Agile_Assignment
<TestClass()> Public Class UnitTest1

    <TestMethod()> Public Sub TestMethod1()
        Dim m As New MsgBoxStyle
        Dim form1 As New Form1

        m = MsgBoxStyle.Information
        MsgBox("Exit Program ?", MsgBoxStyle.Information, vbOKCancel)

    End Sub
End Class